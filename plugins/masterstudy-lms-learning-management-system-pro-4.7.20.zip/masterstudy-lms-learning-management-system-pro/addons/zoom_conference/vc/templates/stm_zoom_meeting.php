<?php
// phpcs:ignoreFile
$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract( $atts );
if ( ! empty( $meeting_id ) ) {
    echo do_shortcode( '[MSLMS_ZOOM_conference post_id="' . $meeting_id . '"]' );
}