<?php
// phpcs:ignoreFile
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoomUpdates.php';
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoomUpdatesCallbacks.php';
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoom.php';
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoomAdminMenus.php';
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoomAdminNotices.php';
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoomPostTypes.php';
require_once MSLMS_ZOOM_PATH . '/zoom-conference/StmZoomAPITypes.php';

//call callback updates
MSLMS_StmZoomUpdates::init();

// Create objects
new MSLMS_StmZoom;
new MSLMS_StmZoomAdminMenus;
new MSLMS_StmZoomAdminNotices;
new MSLMS_StmZoomPostTypes;
