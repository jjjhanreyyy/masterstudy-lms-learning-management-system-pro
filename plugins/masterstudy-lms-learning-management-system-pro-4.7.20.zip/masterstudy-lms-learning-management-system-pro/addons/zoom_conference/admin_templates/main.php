<?php
// phpcs:ignoreFile

include MSLMS_ZOOM_PATH . '/admin_templates/notices/feedback.php';
include MSLMS_ZOOM_PATH . '/admin_templates/notices/pro_popup.php';

if(!empty($_GET['page']) && $_GET['page'] === 'mslms_zoom_users') {
    require_once MSLMS_ZOOM_PATH . '/admin_templates/users.php';
}
else if(!empty($_GET['page']) && $_GET['page'] === 'mslms_zoom_add_user') {
    require_once MSLMS_ZOOM_PATH . '/admin_templates/add_users.php';
}
else if(!empty($_GET['page']) && $_GET['page'] === 'mslms_zoom_reports') {
    require_once MSLMS_ZOOM_PATH . '/admin_templates/reports.php';
}
else if(!empty($_GET['page']) && $_GET['page'] === 'mslms_zoom_assign_host_id') {
    require_once MSLMS_ZOOM_PATH . '/admin_templates/assign_host.php';
}
else {
	// Default: Redirect to Users page since meetings are now under eRoom
	wp_redirect( admin_url( 'admin.php?page=mslms_zoom_users' ) );
	exit;
}