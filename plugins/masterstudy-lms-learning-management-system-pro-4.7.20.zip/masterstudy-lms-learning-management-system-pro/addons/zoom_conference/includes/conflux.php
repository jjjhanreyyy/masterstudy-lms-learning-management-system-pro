<?php
// phpcs:ignoreFile
add_action( 'admin_footer', 'mslms_stm_eroom_render_feature_request' );

function mslms_stm_eroom_render_feature_request() {
	echo '<a id="eroom-feature-request" href="https://stylemixthemes.cnflx.io/boards/eroom-zoom-meetings" target="_blank" style="display: none;">
		<img src="' . esc_url( MSLMS_ZOOM_URL . 'assets/images/conflux/feature-request.svg' ) . '">
		<span>Create a roadmap with us:<br>Vote for next feature</span>
	</a>';
}
