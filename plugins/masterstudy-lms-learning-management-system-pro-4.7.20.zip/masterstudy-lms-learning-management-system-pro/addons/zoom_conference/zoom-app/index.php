<?php
// phpcs:ignoreFile

// Use main plugin's autoloader instead of local vendor
require_once dirname( __DIR__, 2 ) . '/vendor/autoload.php';

$zoom = new \Zoom\ZoomAPI();


var_dump( $zoom->createUser() );
exit();

